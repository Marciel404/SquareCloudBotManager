function play() {
    var video = document.getElementById("video");
    video.play();
  }